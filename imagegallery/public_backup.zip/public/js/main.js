
// $(document).ready(function() {

function openModal() {
    document.getElementById('myModal').style.display = "block";
}
    
function closeModal() {
    document.getElementById('myModal').style.display = "none";
}

// THis function gets data from the server
getData();

var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
    showDivs(slideIndex += n);
}

function currentDiv(n) {
    showDivs(slideIndex = n);
}

function showDivs(n) {
    if (screen.width > 490) {

    
        var i;
        var x = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        var captionText = document.getElementById("caption");
        if (n > x.length) {slideIndex = 1}
        if (n < 1) {slideIndex = x.length}
        for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace("w3-opacity-off", "");

        }
        x[slideIndex-1].style.display = "block";
        dots[slideIndex-1].className += "w3-opacity-off";
    }
// captionText.innerHTML = dots[slideIndex-1].alt;

}


var myIndex = 1;
var caroFunction = carousel();

setInterval(caroFunction, 12000);

function carousel() {
    if (screen.width > 490) {
        var i;
        var x = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("imgSel");
        for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";  
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" w3-opacity-off", "");
        }
        slideIndex++;
        if (slideIndex > x.length) {slideIndex = 1}    
        x[slideIndex-1].style.display = "block"; 
        dots[slideIndex-1].className += " w3-opacity-off";
        setTimeout(carousel, 9000);    
    }
}

/* 
    Code for the Upload form.
*/
var mainCont = document.querySelector(".main-column");
var uploadForm = document.querySelector(".file-Upload");


$(".uploadButton").click(function() {
    // var mainCont = document.querySelector(".main-container");
    // var uploadForm = document.querySelector(".file-Upload");

    mainCont.style.display = "none";
    uploadForm.style.display = "block";
});

$(".cancel-Upload").click((e) => {
    // var mainCont = document.querySelector(".main-container");
    // var uploadForm = document.querySelector(".file-Upload");

    mainCont.style.display = "grid";
    uploadForm.style.display = "none";
});




/* This is the section to retrieve the image files 
from the server.
*/

function getData() {
    var theMainTag = document.querySelector(".main-column");
    var largeImgTag = document.querySelector(".large-Section");
    var thumbsImgTag = document.querySelector(".thumbs-Section");

    theMainTag.innerHTML = "";
    largeImgTag.innerHTML = "";
    thumbsImgTag.innerHTML = "";    

    // theMainTag.innerHTML = "";
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "http://localhost:3000/search?", false);

    xhr.onload = function () {
        if (xhr.status === 200) {
            console.log("sucess, status code is 200");

            var data = xhr.responseText;
            var dataObj = JSON.parse(data);


            console.log(data);
            console.log(dataObj);
            // return dataObj.images;

            var images = dataObj.images;
            var id = 1;
            images.forEach(element => {
                var tags = element.tags;
                if (screen.width > 490) {
                    
                    theMainTag.innerHTML += '<figure>' +
                                                '<img class="thumb" src="  ../images/'+ element.image +'" onclick="openModal();currentDiv('+ id +')">' +
                                                '<figcaption class="fgcap">'+ tags[0] +'</figcaption>' +
                                            '</figure>';  

                    largeImgTag.innerHTML += '<div class="mySlides">' +
                                                '<img class="large-Images w3-animate-fading" src="../images/'+ element.image +'" alt="'+ tags[0] +'" style="width:100%">' +
                                                '<div class="carousel-caption d-none d-md-block">' +
                                                    '<h5 class="img-Title">'+ tags[0] +'</h5>' +
                                                    '<p class="img-Text">Description yet to come.</p>' +
                                                '</div>' +
                                            '</div>';                            

                    thumbsImgTag.innerHTML += '<div class="w3-col l2">' +
                                                '<img class="imgSel demo w3-opacity w3-hover-opacity-off" src="../images/' + element.image +'" style="width:100%" onclick="currentDiv('+ id +')" alt="'+ tags[0] +'">' +
                                            '</div>';
                }
                else {
                    
                    theMainTag.innerHTML += '<figure>' +
                                                '<img class="thumb" src="  ../images/'+ element.image +'">' +
                                                '<figcaption class="fgcap">'+ tags[0] +'</figcaption>' +
                                            '</figure>';  
                }
                
                id++;
            });
            
        }
    }

    xhr.send();
} 
/*
function showImages() {
    var images = getData();
    console.log('​showImages -> images', images);
    // var images = imgObj.images;


    // The tags to received the figures
    var theMainTag = document.querySelector("main-column");

    images.forEach(element => {
        var id = 1;
        var tags = element.tags;
        theMainTag.innerHTML += '<figure>' +
                                    '<img class="thumb" src="' + element.image + '" onclick="openModal();currentDiv('+ id +')"' +
                                    '<figcaption class="fgcap">'+ tags[i] +'</figcaption>' +
                                '</figure>';    
    });
}*/

// showImages();

function searchImages() {
    
    var searchImgTag = document.querySelector(".search-Tag").value;

    if (searchImgTag == "")
        getData();
    else {
        var theMainTag = document.querySelector(".main-column");
        var largeImgTag = document.querySelector(".large-Section");
        var thumbsImgTag = document.querySelector(".thumbs-Section");


        theMainTag.innerHTML = "";
        largeImgTag.innerHTML = "";
        thumbsImgTag.innerHTML = "";

        var xhr = new XMLHttpRequest();
        xhr.open("GET", "http://localhost:3000/search?q="+ searchImgTag, false);

        xhr.onload = function () {
            if (xhr.status === 200) {
                console.log("sucess, status code is 200");

                var data = xhr.responseText;
                var dataObj = JSON.parse(data);


                console.log(data);
                console.log(dataObj);
                // return dataObj.images;

                var images = dataObj.images;
                var id = 1;
                images.forEach(element => {
                    if (screen.width >= 491) {
                        var tags = element.tags;
                        theMainTag.innerHTML += '<figure>' +
                                                    '<img class="thumb" src="  ../images/'+ element.image +'" onclick="openModal();currentDiv('+ id +')">' +
                                                    '<figcaption class="fgcap">'+ tags[0] +'</figcaption>' +
                                                '</figure>';  
    
                        largeImgTag.innerHTML += '<div class="mySlides">' +
                                                    '<img class="large-Images w3-animate-fading" src="../images/'+ element.image +'" alt="'+ tags[0] +'" style="width:100%">' +
                                                    '<div class="carousel-caption d-none d-md-block">' +
                                                        '<h5 class="img-Title">'+ tags[0] +'</h5>' +
                                                        '<p class="img-Text">Description yet to come.</p>' +
                                                    '</div>' +
                                                '</div>';                            
    
                        thumbsImgTag.innerHTML += '<div class="w3-col l2">' +
                                                    '<img class="imgSel demo w3-opacity w3-hover-opacity-off" src="../images/' + element.image +'" style="width:100%" onclick="currentDiv('+ id +')" alt="'+ tags[0] +'">' +
                                                '</div>';
                    }
                    else {
                        var tags = element.tags;
                        theMainTag.innerHTML += '<figure>' +
                                                    '<img class="thumb" src="  ../images/'+ element.image +'">' +
                                                    '<figcaption class="fgcap">'+ tags[0] +'</figcaption>' +
                                                '</figure>';  
                    }
                    id++;
                });
                return;
            }
        }

        xhr.send();
    }

}