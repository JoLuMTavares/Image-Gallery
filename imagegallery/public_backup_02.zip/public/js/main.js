

function openModal() {
    document.getElementById('myModal').style.display = "block";
}

function closeModal() {
    document.getElementById('myModal').style.display = "none";
}

// This function gets data from the server
getData();

var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
    showDivs(slideIndex += n);
}

function currentDiv(n) {
    showDivs(slideIndex = n);
}

function showDivs(n) {
    //  if (screen.width > 490) {
    
        var i;
        var x = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        var captionText = document.getElementById("caption");
        if (x.length > 0) {

            if (n > x.length) {slideIndex = 1}
            if (n < 1) {slideIndex = x.length}
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace("w3-opacity-off", "");

            }
        
            x[slideIndex-1].style.display = "block";
            dots[slideIndex-1].className += "w3-opacity-off";
        }
       
        //  carousel();
    //  }

}


var myIndex = 1;
// var caroFunction = carousel();

// setInterval(caroFunction, 12000);

function carousel() {
    // if (screen.width > 490) {
        var i;
        var x = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("imgSel");
        if (x.length > 0) {
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";  
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" w3-opacity-off", "");
            }
            slideIndex++;
        
            
            if (slideIndex > x.length) {slideIndex = 1}    
            x[slideIndex-1].style.display = "block"; 
            dots[slideIndex-1].className += " w3-opacity-off";        
            setTimeout(carousel, 9000);  
        }
          
    // }
}

/* 
    Code for the Upload form.
*/

var mainCont = document.querySelector(".main-column");
var uploadForm = document.querySelector(".file-Upload");


$(".uploadButton").click(function() {

    mainCont.style.display = "none";
    uploadForm.style.display = "block";
});

$(".cancel-Upload").click((e) => {

    mainCont.style.display = "grid";
    uploadForm.style.display = "none";
});




/* This is the section to retrieve the image files 
from the server.
*/

function getData() {
    var theMainTag = document.querySelector(".main-column");
    var largeImgTag = document.querySelector(".large-Section");
    var thumbsImgTag = document.querySelector(".thumbs-Section");

    theMainTag.innerHTML = "";
    largeImgTag.innerHTML = "";
    thumbsImgTag.innerHTML = "";    

    var xhr = new XMLHttpRequest();
    xhr.open("GET", "http://localhost:3000/search?");

    xhr.onload = function () {
        if (xhr.status === 200) {
            console.log("success, status code is 200");

            var data = xhr.responseText;
            var dataObj = JSON.parse(data);


            console.log(data);
            console.log(dataObj);

            var images = dataObj.images;
            var id = 1;
            images.forEach(element => {
                var tags = element.tags;
                if (screen.width > 490) {
                    
                    theMainTag.innerHTML += "<figure class='image-Thumb'>" +
                                                "<button type='submit' id='remove-Image' onclick='removeImage(\""+ tags[1] +"\");'><i class='ion-android-delete' title='Remove this image'></i></button>" +    
                                                "<img class='thumb' src='  ../images/"+ element.image +"' onclick='openModal();currentDiv("+ id +");carousel();'>" +
                                                "<figcaption class='fgcap'>"+ tags[1] +"</figcaption>" +
                                            "</figure>";  

                    largeImgTag.innerHTML += '<div class="mySlides">' +
                                                '<img class="large-Images w3-animate-fading" src="../images/'+ element.image +'" alt="'+ tags[1] +'" style="width:100%">' +
                                                '<div class="carousel-caption d-none d-md-block">' +
                                                    '<h5 class="img-Title">'+ tags[1] +'</h5>' +
                                                    '<p class="img-Text">Description yet to come.</p>' +
                                                '</div>' +
                                            '</div>';                            

                    thumbsImgTag.innerHTML += '<div class="w3-col l2">' +
                                                '<img class="imgSel demo w3-opacity w3-hover-opacity-off" src="../images/' + element.image +'" style="width:100%" onclick="currentDiv('+ id +')" alt="'+ tags[0] +'">' +
                                            '</div>';
                }
                else {
                    
                    theMainTag.innerHTML += '<figure>' +
                                                '<img class="thumb" src="  ../images/'+ element.image +'">' +
                                                '<figcaption class="fgcap">'+ tags[1] +'</figcaption>' +
                                            '</figure>';  
                }
                
                id++;
            });
            
        }
    }
    xhr.send();
} 

function searchImages() {
    
    var searchImgTag = document.querySelector(".search-Tag").value;

    if (searchImgTag == "")
        getData();
    else {
        var theMainTag = document.querySelector(".main-column");
        var largeImgTag = document.querySelector(".large-Section");
        var thumbsImgTag = document.querySelector(".thumbs-Section");


        theMainTag.innerHTML = "";
        largeImgTag.innerHTML = "";
        thumbsImgTag.innerHTML = "";

        var xhr = new XMLHttpRequest();
        xhr.open("GET", "http://localhost:3000/search?q="+ searchImgTag);

        xhr.onload = function () {
            if (xhr.status === 200) {
                console.log("sucess, status code is 200");

                var data = xhr.responseText;
                var dataObj = JSON.parse(data);


                console.log(data);
                console.log(dataObj);

                var images = dataObj.images;
                var id = 1;
                images.forEach(element => {
                     if (screen.width >= 491) {
                        var tags = element.tags;
                        theMainTag.innerHTML += "<figure class='image-Thumb'>" +
                                                    "<button type='submit' id='remove-Image' onclick='removeImage(\""+ tags[1] +"\");'><i class='ion-android-delete' title='Remove this image'></i></button>" +    
                                                    "<img class='thumb' src='  ../images/"+ element.image +"' onclick='openModal();currentDiv("+ id +");carousel();'>" +
                                                    "<figcaption class='fgcap'>"+ tags[1] +"</figcaption>" +
                                                "</figure>";  
    
                        largeImgTag.innerHTML += '<div class="mySlides">' +
                                                    '<img class="large-Images w3-animate-fading" src="../images/'+ element.image +'" alt="'+ tags[1] +'" style="width:100%">' +
                                                    '<div class="carousel-caption d-none d-md-block">' +
                                                        '<h5 class="img-Title">'+ tags[1] +'</h5>' +
                                                        '<p class="img-Text">Description yet to come.</p>' +
                                                    '</div>' +
                                                '</div>';                            
    
                        thumbsImgTag.innerHTML += '<div class="w3-col l2">' +
                                                    '<img class="imgSel demo w3-opacity w3-hover-opacity-off" src="../images/' + element.image +'" style="width:100%" onclick="currentDiv('+ id +')" alt="'+ tags[1] +'">' +
                                                '</div>';
                    }
                    else {
                        var tags = element.tags;
                        theMainTag.innerHTML += '<figure>' +
                                                    '<img class="thumb" src="  ../images/'+ element.image +'">' +
                                                    '<figcaption class="fgcap">'+ tags[1] +'</figcaption>' +
                                                '</figure>';  
                    }
                    id++;
                });
                return;
            }
        }

        xhr.send();
    }

}

/* This function removes an image */
function removeImage(tag) {
    
    //  var tagNoSpace = str.trim(tag);
    /*
    if(confirm("This image - "+ tag.trim() +" - is about to be removed.\n Do you confirm?")) {
        var theMainTag = document.querySelector(".main-column");
        var largeImgTag = document.querySelector(".large-Section");
        var thumbsImgTag = document.querySelector(".thumbs-Section");

        // Getting the form
        var deleteForm = document.getElementById("deleteForm");
        var inputTag = document.createElement("INPUT");
        inputTag.setAttribute("type", "text");
        inputTag.setAttribute("value", tag.trim());
        
        // Assigning the tag to the input
        // deleteForm

        // Submitting the form
        deleteForm.appendChild(inputTag);
        deleteForm.submit();

        theMainTag.innerHTML = "";
        largeImgTag.innerHTML = "";
        thumbsImgTag.innerHTML = "";

        var xhr = new XMLHttpRequest();
        // xhr.open("DELETE", "http://localhost:3000/:image?q="+ tag.trim());

        xhr.open("GET", "http://localhost:3000/search?");

        xhr.onload = function () {
            if (xhr.status === 200) {
                console.log("success, status code is 200");

                var data = xhr.responseText;
                var dataObj = JSON.parse(data);


                console.log(data);
                console.log(dataObj);

                var images = dataObj.images;
                var id = 1;
                images.forEach(element => {
                    var tags = element.tags;
                    if (screen.width > 490) {
                        
                        theMainTag.innerHTML += "<figure class='image-Thumb'>" +
                                                    "<button type='submit' id='remove-Image' onclick='removeImage(\""+ tags[1] +"\");'><i class='ion-android-delete' title='Remove this image'></i></button>" +    
                                                    "<img class='thumb' src='  ../images/"+ element.image +"' onclick='openModal();currentDiv("+ id +")'>" +
                                                    "<figcaption class='fgcap'>"+ tags[1] +"</figcaption>" +
                                                "</figure>";  

                        largeImgTag.innerHTML += '<div class="mySlides">' +
                                                    '<img class="large-Images w3-animate-fading" src="../images/'+ element.image +'" alt="'+ tags[1] +'" style="width:100%">' +
                                                    '<div class="carousel-caption d-none d-md-block">' +
                                                        '<h5 class="img-Title">'+ tags[1] +'</h5>' +
                                                        '<p class="img-Text">Description yet to come.</p>' +
                                                    '</div>' +
                                                '</div>';                            

                        thumbsImgTag.innerHTML += '<div class="w3-col l2">' +
                                                    '<img class="imgSel demo w3-opacity w3-hover-opacity-off" src="../images/' + element.image +'" style="width:100%" onclick="currentDiv('+ id +')" alt="'+ tags[0] +'">' +
                                                '</div>';
                    }
                    else {
                        
                        theMainTag.innerHTML += '<figure>' +
                                                    '<img class="thumb" src="  ../images/'+ element.image +'">' +
                                                    '<figcaption class="fgcap">'+ tags[1] +'</figcaption>' +
                                                '</figure>';  
                    }
                    
                    id++;
                });
            
            }
        }

        xhr.send();
    }*/
}